import {
  MatDivider,
  MatDividerModule
} from "./chunk-F7NZWFTP.js";
import "./chunk-U4SHWFKD.js";
import "./chunk-4KKZ4AM2.js";
import "./chunk-C2TQF7UW.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
