import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AuthentificationService } from '../services/authentification.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { User } from '../model/user.model';
import { Role } from '../model/role';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  public loginFormGroup! : FormGroup;
  private users: User[] = [];
  isSignin: boolean = false;
  errorMessage: string = '';
  constructor(private fb : FormBuilder,
              private route: ActivatedRoute,
              private authService : AuthentificationService,
              private userService: UserService,
              private router : Router) {
  }
  ngOnInit() {
    this.loginFormGroup = this.fb.group({
      username : this.fb.control(''),
      password : this.fb.control('')
    });
    this.route.url.subscribe(urlSegments => {
      this.isSignin = urlSegments.some(segment => segment.path === 'signin');
    });
    this.userService.getUsers().subscribe(data => this.users = data);
  }

  loginOrSignin() {
    let username = this.loginFormGroup.value.username;
    let password = this.loginFormGroup.value.password;
    const existingUser = this.users.find(user => user.id === username && user.password === password);

    // quand on créer un compte
    if(this.isSignin){
      this.signin(existingUser, username, password)
    }
    // quand on se connecte
    else{
      this.login(existingUser)
    }
  }

  login(existingUser: User | undefined){
    const auth = this.authService.login(existingUser);
    if(auth==true){
      this.router.navigateByUrl("/admin");
    }
    else{
      this.errorMessage = "Identifiant ou mot de passe incorrect."
    }
  }

  signin(existingUser: User | undefined, username: string, password: string) {
    const auths = this.authService.signin(existingUser, username);
    if(auths==true){
      this.userService.addUser({"id": username, "password": password, "role": Role.USER} as User).subscribe({
        error: (err) => { alert(err.message); },
      })
      this.router.navigateByUrl("/admin");
    }
    else{
      this.errorMessage = "Utilisateur déjà existant."
    }
  }
}
