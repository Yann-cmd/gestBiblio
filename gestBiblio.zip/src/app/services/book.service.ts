import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from '../model/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private bookUrl = "http://localhost:3000/books"

  constructor(private http: HttpClient) { }

  // Récupérer les livres
  getBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(this.bookUrl);
  }

  // Ajouter un livre
  addBook(book: Book): Observable<Book> {
    return this.http.post<Book>(this.bookUrl, book)
  }

  // Mettre à jour un livre
  updateBook(book: Book): Observable<Book> {
    return this.http.put<Book>(`${this.bookUrl}/${book.id}`, book)
  }

  // Supprimer un livre par son id
  deleteBook(id: string): Observable<Book> {
    return this.http.delete<Book>(`${this.bookUrl}/${id}`)
  }

  // Récupérer un livre par son id
  getBookById(id: string): Observable<Book> {
    return this.http.get<Book>(`${this.bookUrl}/${id}`);
  }
}
