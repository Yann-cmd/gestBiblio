import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../model/user.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private userUrl = "http://localhost:3000/users"

  constructor(private http: HttpClient) { }

  // Récupérer les utilisateurs
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.userUrl);
  }

  // Ajouter un livre
  addUser(user: User): Observable<User> {
    return this.http.post<User>(this.userUrl, user)
  }
}
