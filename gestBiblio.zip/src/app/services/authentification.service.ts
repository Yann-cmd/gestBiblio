import { Injectable } from '@angular/core';
import {Router} from "@angular/router";
import { UserService } from './user.service';
import { User } from '../model/user.model';
import { Role } from '../model/role';

@Injectable({
  providedIn: 'root'
})
export class AuthentificationService {
  public username : any;
  public roles : string[] = [];
  public users: User[] = [];
  public authenticated : boolean = false;
  constructor(private router : Router, private userService: UserService) { }

  public login(existingUser: User | undefined){
    if(existingUser != undefined){
      this.username = existingUser.id;
      this.roles = [existingUser.role];
      this.authenticated = true;
      return true;
    } else {
      return false;
    }
  }

  public signin(existingUser: User | undefined, username: string){
    // si l'user existe deja avec id/password combinaison, on met un message d'erreur
    if(existingUser != undefined){
      return false;
    }
    else{
      this.username = username;
      this.roles = [Role.USER];
      this.authenticated = true;
      return true;
    }
  }

  logout() {
    this.authenticated=false;
    this.username = undefined;
    this.roles = [];
    this.router.navigateByUrl("/login");
  }
}
