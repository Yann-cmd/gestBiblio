import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Book } from '../model/book.model';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../services/book.service';

@Component({
  selector: 'app-books-form',
  templateUrl: './books-form.component.html',
  styleUrl: './books-form.component.css'
})
export class BooksFormComponent implements OnInit {
  public bookForm!:FormGroup;
  books: Book[] = [];
  isEditMode: boolean = false;
  bookId: string = '';

  constructor(private fb: FormBuilder, private bookService:BookService, private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.bookService.getBooks().subscribe(data => this.books = data);
    this.bookForm=this.fb.group({
      title : this.fb.control('', [Validators.required]),
      price : this.fb.control('0', [Validators.required]),
      author : this.fb.control('', [Validators.required]),
      date : this.fb.control('', [Validators.required]),
    });

    // Vérifiez si un ID est passé dans l'URL
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true; // On est en mode édition
        this.bookId = params['id']

        // Chargez les données de l'objet et remplissez le formulaire
        this.bookService.getBookById(this.bookId).subscribe(book => {
          this.bookForm.patchValue({
            title: book.title,
            price: book.price,
            author: book.author,
            date: book.publicationDate
          });
        });
      }
    });
  }

  // Ajouter un produit
  saveBook(): void {
    if (this.bookForm.valid) {
      //par défaut, create strategy
      const book: Book = {
        id: (parseInt(this.books[this.books.length-1].id) + 1).toString(),
        title: this.bookForm.value.title,
        price: this.bookForm.value.price,
        author: this.bookForm.value.author,
        publicationDate: this.bookForm.value.date,
      };

      // update strategy
      if(this.isEditMode){
        book.id = this.bookId;
        this.bookService.updateBook(book).subscribe({
          error: (err) => { alert(err.message); },
        })
      }
      else{
        this.bookService.addBook(book).subscribe({
          error: (err) => { alert(err.message); },
        })
      }
      this.router.navigate(['/admin/books']);
    }
  }
}
