import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Book } from '../model/book.model';
import { BookService } from '../services/book.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { AuthentificationService } from '../services/authentification.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrl: './books.component.css'
})
export class BooksComponent implements OnInit, AfterViewInit{
  books: MatTableDataSource<Book> = new MatTableDataSource<Book>([]);
  displayedColumns: string[] = ['title', 'author', 'price', 'publicationDate'];

  @ViewChild(MatPaginator) paginator! : MatPaginator;
  @ViewChild(MatSort) sort! : MatSort;

  constructor(private bookService: BookService, private router: Router, public authService : AuthentificationService){}
  ngOnInit(): void {
    if(this.authService.roles.includes("ADMIN")){
      this.displayedColumns.push("actions")
    }
    this.getBooks()
  }

  ngAfterViewInit() {
    this.books.paginator = this.paginator;
    this.books.sort = this.sort;
  }

  private getBooks(){
    this.bookService.getBooks().subscribe(books => {
      this.books.data = books;
    });
  }

  handleEdit(book: Book): void {
    this.router.navigate([`/admin/edit/${book.id}`]);
  }

  handleDelete(book: Book): void {
    if(confirm("Etes vous sûre?")){
      this.bookService.deleteBook(book.id).subscribe({
        error: (err) => { alert(err.message); },
        complete: () => {
          this.getBooks();
        }
      });
    }
  }
}
