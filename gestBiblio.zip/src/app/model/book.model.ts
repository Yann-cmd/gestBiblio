export interface Book {
    id : string,
    title : string,
    price : number,
    author: string,
    publicationDate : Date
}